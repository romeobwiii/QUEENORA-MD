 **🧚‍♀️ QUEENORA-MD**


</p> <p align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Rubik+Dirt&size=65&pause=1000&color=F20C39F&background=FF20A500&center=true&vCenter=true&width=1000&height=150&lines=QUEENORA+MD;MADE+BY+ROMEO +BW+III" alt="Typing SVG" 
---
1. Fork The Repo
    <br>
<a href="https://github.com/Sudaisz/Momo-md.git/fork"><img title="MOMO-MD" src="https://img.shields.io/badge/FORK MOMO-MD-h?color=black&style=for-the-badge&logo=stackshare"></a>

![forks](https://img.shields.io/github/forks/https://github.com/Sudaisz/Momo-md.git?label=Forks&style=social)

![stars](https://img.shields.io/github/stars/Sudaisz/Momo-md.git?style=social)




<br>
• FAST AND REALIABLE BOT
<br>


  <p align="center">  
  <a href="https://i.imgur.com/05b4RaE.jpeg">
    <img alt="QUEENORA MD" height="200" src="https://i.ibb.co/gLgdgLjT/IMG-20250201-WA0143.jpg">
    
   Loading...
  <img src="https://github.com/AnderMendoza/AnderMendoza/raw/main/assets/line-neon.gif" width="100%">



---

**1.  PAIR CODE GET**
    <br>

<p align="left">
<a href='https://sahas-md-pair-web-ibx9.onrender.com/' target="_blank"><img alt='Pair Code' src='https://img.shields.io/badge/-Pair Code-darkgreen?style=for-the-badge&logo=Whatsapp&logoColor=white'/< width=120 height=39/p></a>

    
---
 **2.  Deploy To Replit**

<a href="https://replit.com"><img title="MOMO-MD Deploy Replit" src="https://img.shields.io/badge/DEPLOY REPLIT-h?color=black&style=for-the-badge&logo=Replit"></a>
---
**3. Deploy to HEROKU ↓**

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Sudaisz/Momo-md.git)

 **4.  Deploy to RENDER ↓**

<a href="https://dashboard.render.com/" target="blank"><img align="center" src="https://i.ibb.co/gLgdgLjT/IMG-20250201-WA0143.jpg" width="100" height="20" alt="Deploy bot"/></a>

---





---
**5. Deploy to GITHUB**

  WORKFLOW CODE
 ```name: Node.js CI

on:
  push:
    branches:
      - main
  pull_request:
    branches:
      - main

jobs:
  build:

    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [20.x]

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}

    - name: Install dependencies
      run: npm install

    - name: Start application
      run: npm start
```
---


## CREDITS 
# `OWNER`

 <a href="https://files.catbox.moe/q1k87h.jpg"><img src="https://files.catbox.moe/q1k87h.jpg" width="250" height="300" alt=" ROMEO BW III"/></a>

---
### DEVELOPERS:

1. ### ROMEO BW III

## MY YT CHANNEL

[![Youtube](https://telegra.ph/file/eebe86c26e98ffeae39ea.jpg)](https://youtube.com/normal31_31) 
 
 ### WHATSAPP CHANNLE 👇
 <p align="left">
<a href='[https://github.com/romeobwiii/QUEENORA-md.git](https://github.com/romeobwiii/QUEENORA-md.git)' target="_blank"><img alt='WhatsApp Channel' src='https://img.shields.io/badge/-WhatsApp Channel-darkgreen?style=for-the-badge&logo=Whatsapp&logoColor=white'/< width=120 height=39/p></a>


